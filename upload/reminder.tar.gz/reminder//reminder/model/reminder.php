<?php
require_once('connection.php');
class reminder extends Zend_Db_Table_Abstract
{
    protected $_name = 'reminder';
    protected $_dependentTables = NULL;
    protected $_referenceMap    = array(
    
    );
}
