<?php
require_once("Zend/Db.php");
require_once("Zend/Db/Table.php");
$db = Zend_Db::factory("Mysqli", array (
  'host' => 'localhost',
  'username' => 'root',
  'password' => 'root',
  'dbname' => 'reminder',
  '__ideNodeOpen' => 'true',
));
Zend_Db_Table_Abstract::setDefaultAdapter($db);
