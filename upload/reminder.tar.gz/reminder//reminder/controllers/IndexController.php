<?php
/** Zend_Controller_Action */
require_once 'Zend/Controller/Action.php';
require_once 'Zend/Loader.php';
/**
 * 
 * @author 
 */
class IndexController extends Zend_Controller_Action
{

  /**
   * 
   */
  public function indexAction()
  {
    
    
  }

  /**
   * 
   */
  public function pageAction()
  {
    
    $this->_helper->viewRenderer->setNoRender();
require_once("../library/book.class.php");

print book::getPage($_GET["i"], $_GET["b"]);

  }

  /**
   * 
   */
  public function controlAction()
  {
    
    $this->_helper->viewRenderer->setNoRender();
ob_start();
?>
<div class="ctl_label"><button type="button" onclick="window.remindEmail()"><img src="../../images/mail.gif"/></button>Create an Email-reminder</div>
<div id="datepicker" style="font-size:10px"></div>
<?php
$cont=ob_get_contents();
ob_end_clean();
?>
window.remindEmail=function(){
  var page=book.insert('<div class="rem"><span class="rem_fieldLabel">To:</span><input class="rem_to" name="to" value="to@email.com"/><br /><span class="rem_fieldLabel">Subject:</span><input class="rem_subject" name="subject"/><br /><span class="rem_fieldLabel">Time:</span><input class="rem_subject inputTime" name="time"/><br /><textarea class="rem_body" name="body"></textarea><span style="display:inline-block"><a class="button" href="#" onclick="cancela_reg(this.parentNode)"><img src="../../images/dialog-delete.gif"/></a><br /><a class="button" href="#" onclick="registrar(this.parentNode.parentNode)"><img src="../../images/check.png"/></a></span></div>');
  $(page).find("[name=to]").select();
  $('.inputTime').ptTimeSelect();
}
window.registrar=function(pa){
  var to=$(pa).find("[name=to]")[0].value;
  var subject=$(pa).find("[name=subject]")[0].value;
  var body=$(pa).find("[name=body]")[0].value;
  var time=$(pa).find("[name=time]")[0].value;
  enviar("remind",{to:to,subject:subject,body:body,date:buffer.getDate(paginaActual),time:time});
}
window.cancela_reg=function(){
  buffer.loadPage(paginaActual);
}
window.datepicker={
  onSelect:function(){
    var $sel = $("#datepicker").datepicker("getDate");
    var $first = new Date($sel.getFullYear(),0,1);
    irA(Math.ceil(($sel - $first) / 86400000));
  },
  onChangePage:function(){
    var $sel = $("#datepicker").datepicker("getDate");
    var $first = new Date(2011,0,1);
    var $doy = Math.ceil(($sel - $first) / 86400000);
    if(paginaActual!=$doy) {
      $sel.setDate($sel.getDate() + (paginaActual-$doy) );
      $("#datepicker").datepicker("setDate", $sel );
    }
  }
}
$(".control").html(<?php print json_encode($cont) ?>);
$("#datepicker").datepicker({inline:true,onSelect:function(){window.datepicker.onSelect()}});
datepicker.onChangePage();
<?php
  }

  /**
   * 
   */
  public function tabsAction()
  {
    
    $this->_helper->viewRenderer->setNoRender();
require_once("../library/book.class.php");

print "var tabs=" . json_encode(book::getTabs()). ";";

?>
for(var i=0,l=tabs.length;i<l;i++){
  book.addTab(tabs[i].i,tabs[i].L,tabs[i].p);
}
<?php
  }

  /**
   * 
   */
  public function remindAction()
  {
    foreach($this->getRequest()->getParams() as $_ => $__) if(substr($_,0,1)!="_") $$_=$__;
    $this->_helper->viewRenderer->setNoRender();
//ini_set("display_errors","on");
//error_reporting(E_ALL);

$user = $_SESSION["user"];

list($Y,$m,$d) = explode("-",$date);
preg_match('/(\d+):(\d+) (\w+)/', $time, $ma);
list($tm,$H,$i,$ampm) = $ma;

if($H=="12") {if($ampm=="AM") $H=0;}
else {if($ampm=="PM") $H=$H+12;}
$H = $H % 24;

$send_on = mktime($H, $i, 0, $m, $d, $Y);

        try {
          require_once("../model/reminder.php");
          $table=new reminder();
          $values=array();
          $values["to"]=$to;
          $values["subject"]=$subject;
          $values["body"]=$body;
          $values["date"]=$date;
          $values["rem_from"]=$user;
          $values["time"]=$time;
          $values["sent"]=0;
          $values["send_on"]=$send_on;
          
          $table->insert($values);
        } catch (Exception $e) {
          exit("{success:false,errors:[{msg:".json_encode($e->getMessage())."}]}");
        }

?>
buffer.loadPage(paginaActual);
<?php
  }

  /**
   * 
   */
  public function loginAction()
  {
    $user=$this->getRequest()->getParam("user"); $password=$this->getRequest()->getParam("password"); 
    $this->_helper->viewRenderer->setNoRender();        try {
          require_once("../model/usuario.php");
          $table=new usuario();
          $select=$table->select();
          $select->where('usr_login=?',$user);

          $select->where('usr_password=md5(?)',$password);

          $row=$table->fetchRow($select);
          
if($row){
  require_once("../library/book.class.php");
  
  print book::login($row->usr_login, $password);
 
} else {
  print '$("#user")[0].value="";$("#password")[0].value="";$("#loginmsg").html("Failed login.");$("#user")[0].focus();';

}
        } catch (Exception $e) {
          exit("{success:false,errors:[{msg:".json_encode($e->getMessage())."}]}");
        }

  }

  /**
   * 
   */
  public function cronAction()
  {
    foreach($this->getRequest()->getParams() as $_ => $__) if(substr($_,0,1)!="_") $$_=$__;
    $this->_helper->viewRenderer->setNoRender();
//text

$timestamp = time();

print $timestamp;


        try {
          require_once("../model/reminder.php");
          $_table=new reminder();
          $select=$_table->select();
          @$_limit = null;
          @$_offset = null;
          @$_order = null;
          $select->limit($_limit,$_offset);
          if(isset($_order) && (trim($_order)!="")) $select->order($_order);
          $select->from($_table);
          
          $select->where('SENT=0');

          $select->where('SEND_ON<=?',$timestamp);

          $rows = $_table->fetchAll($select);
          
REQUIRE_ONCE("Zend/Mail/Transport/Smtp.php");
REQUIRE_ONCE("Zend/Mail.php");

//$password = substr(md5("remindersbook"),0,16);
  $config = array('ssl' => 'tls', 'port' => 587, 'auth' => 'login', 'username' => 'reminderbook@hotmail.com', 'password' => '24cb9a886cef7774');
  $tr = new Zend_Mail_Transport_Smtp('smtp.live.com', $config);
  
  Zend_Mail::setDefaultTransport($tr);

foreach($rows as $row ){
try{
  $to = $row->TO;
  $from = $row->REM_FROM;
  $message = $row->BODY;

var_dump($from, $to, $message);
  
  $mail = new Zend_Mail();
  
  $fromName=explode("@",$fromName);
  $fromName=$fromName[0];
  var_dump( $fromName );
  
  $mail->setFrom("reminderbook@hotmail.com", $from );
  $mail->addTo($to, $to);
  $mail->setSubject("Startup Weekend Reminder");
  $htmlMessage = '<div style="width:350px;border:1px solid #99BBE8;border-radius:4px;-webkit-border-radius:4px;-moz-border-radius:4px;">
<div style="color:#15428B;font-family:tahoma,arial,verdana,sans-serif;font-size:11px;font-weight:bold;padding:2px 4px;background-color:#BAD0EE;border-bottom:1px solid #99BBE8;">Reminder</div>
<div style="font-family:tahoma,arial,verdana,sans-serif;font-size:11px;padding:4px;background-color:#DFE8F6;">'.htmlentities($message, ENT_NOQUOTES, 'utf-8').'</div>
<div style="font-family:tahoma,arial,verdana,sans-serif;font-size:11px;padding:4px;background-color:#DFE8F6;"><br />Visit us at: <a href="http://legado.boliviaincuba.net/">legado.boliviaincuba.net</a></div>
<div style="font-family:tahoma,arial,verdana,sans-serif;font-size:11px;padding:4px;background-color:#DFE8F6;">or at Facebook: <a href="http://www.facebook.com/pages/Reminders-Book/161988810566105?sk=app_278343152208414">Reminders-Book</a></div>
</div>';
  $mail->setBodyHtml($htmlMessage);
  //$mail->setBodyText($message);
  $mail->send();
  
  $row->SENT=1;
  $row->save();
} catch(Exception $e){
  //throw $e;
  var_dump($e->getMessage());
}
}


        } catch (Exception $e) {
          exit("{success:false,errors:[{msg:".json_encode($e->getMessage())."}]}");
        }

  }



}
