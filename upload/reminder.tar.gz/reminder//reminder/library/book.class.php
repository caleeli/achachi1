<?php
class book{
  function login($user, $password) {
    $_SESSION["user"] = $user;
    return 'book.logged=true;book.open();';
  }
  function loginPage($b){
    ob_start();
    ?><div class="rem_body" style="position:relative;left:50px;top:150px;height:80px;"><div id="loginmsg" style="color:red;">&nbsp;</div><span class="rem_fieldLabel">User:</span><input id="user"/><br /><br /><span class="rem_fieldLabel">Password:</span><input id="password"/><br /><br />
    <div style="text-align:right;"><a class="button" href="javascript:void(0)" onclick="book.login($('#user')[0].value, $('#password')[0].value)"><img src="../../images/check.png"/></a></div></div><?php
    $cont = ob_get_contents();
    ob_end_clean();
    return 'buffer.buffer['.$b.'].innerHTML=' . json_encode($cont) . ';';
  }
  function getPage($i,$b){
    if($i==-1) return self::loginPage($b);
    $date=strtotime("2011-01-01 +".$i."day");
    $dia = Date("d",$date);
    $mes = Date("M",$date);
    $diaSemana = Date("l",$date);
    $anio = Date("Y",$date);
    $date0=Date("Y-m-d 00:00:00",$date);
    $date1=Date("Y-m-d 23:59:59",$date);
    $user = $_SESSION["user"];
    ob_start();
    ?>
    <span class="h1"><?=$dia ?></span><span class="h2"><?=$mes ?><br /><?=$diaSemana ?></span><span class="h3"> &nbsp; <?=$anio ?></span>
    <hr />
    <?php
        try {
          require_once("../model/reminder.php");
          $_table=new reminder();
          $select=$_table->select();
          @$_limit = null;
          @$_offset = null;
          @$_order = null;
          $select->limit($_limit,$_offset);
          if(isset($_order) && (trim($_order)!="")) $select->order($_order);
          $select->from($_table);
          
          $select->where('rem_from=?',$user);

          $select->where('date>=?',$date0);

          $select->where('date<=?',$date1);

          $rows = $_table->fetchAll($select);
          print '<div class="page_rem">';
foreach($rows as $row){
  print '<div class="rem"><span class="rem_fieldLabel">To:</span><span class="rem_to">'.$row->TO.'</span><br /><span class="rem_fieldLabel">Subject:</span><span class="rem_subject" >'.$row->SUBJECT.'</span><br /><span class="rem_fieldLabel">Time:</span><span class="rem_subject" >'.$row->TIME.'</span><br /><span class="rem_body2">'.$row->BODY.'</span></div>';
}
print '</div>';

        } catch (Exception $e) {
          exit("{success:false,errors:[{msg:".json_encode($e->getMessage())."}]}");
        }

    $cont=ob_get_contents();
    ob_end_clean();
    return 'buffer.buffer['.$b.'].innerHTML=' . json_encode($cont) . ';'.
           'buffer.date['.$b.']='.json_encode(Date("Y-m-d",$date)).';';
  }
  function getTabs(){
    $res=array();
    for($mes=1;$mes<=12;$mes++){
      $date=strtotime("2011-".substr("0".$mes,-2,2)."-01");
      $page=Date("z",$date)+0;
      $mesL=Date("M",$date);
      $res[]=array("i"=>($mes-1),"L"=>$mesL,"p"=>$page);
    }
    return $res;
  }
}
