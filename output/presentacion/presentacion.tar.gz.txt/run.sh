#!/bin/bash
./main.php start
clear
./main.php propel1
vi propel1.php
./main.php propel2
vi propel2.php
./main.php propel3
vi propel3.php
./main.php propel4
vi propel4.php
./main.php propel5
vi propel5.php
./main.php composer1
vi composer1.php
./main.php composer2
vi composer2.php
./main.php composer3
vi composer3.php
./main.php composer4
vi composer4.php
./main.php session1
vi session1.php
./main.php session2
vi session2.php
